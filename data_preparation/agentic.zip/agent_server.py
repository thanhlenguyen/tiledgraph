"""
agent_server.py
A FastAPI backend: the map frontend sends a user message, the agent decides which
GIS tools to call, and the response returns text + GeoJSON layers to draw.

Run:
  pip install anthropic fastapi uvicorn httpx
  export ANTHROPIC_API_KEY=...  GIS_BASE_URL=...  GIS_API_KEY=...
  uvicorn agent_server:app --port 8000
"""
import json
import logging
import os
import time
import uuid

import anthropic
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from gis_tools import TOOLS, run_tool

MODEL = os.getenv("AGENT_MODEL", "claude-sonnet-5-5")
MAX_STEPS = 8  # safety cap on tool-call rounds per request

SYSTEM_PROMPT = """You are the GIS operations assistant for Infinite PL, working on Saudi addresses,
facilities, and delivery fleets. You answer by calling GIS tools, never by guessing locations.

Rules:
- Resolve every place name or short address with geocode_address before using it.
- If geocoding confidence is low or there are several plausible matches, ask the user to choose.
- Use road travel time from tools; never estimate distances yourself.
- optimize_vehicle_routes produces DRAFT plans only. Never claim drivers were dispatched.
- Answer in the user's language (Arabic or English). Be brief: key numbers first, then 1-3 sentences.
- If a request is outside the available tools, say what you can do instead.
"""

client = anthropic.Anthropic()
app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

log = logging.getLogger("gis-agent")
logging.basicConfig(level=logging.INFO)


class ChatRequest(BaseModel):
    messages: list[dict]          # full chat history from the frontend: [{"role","content"}]
    map_view: dict | None = None  # optional current map center/bbox, gives the agent context


@app.post("/chat")
def chat(req: ChatRequest):
    request_id = str(uuid.uuid4())
    messages = list(req.messages)
    if req.map_view:
        # Give the agent awareness of what the user is looking at
        messages[-1] = {
            "role": "user",
            "content": f"{messages[-1]['content']}\n\n[Current map view: {json.dumps(req.map_view)}]",
        }

    layers, trace = [], []

    for step in range(MAX_STEPS):
        resp = client.messages.create(
            model=MODEL,
            max_tokens=2048,
            system=SYSTEM_PROMPT,
            tools=TOOLS,
            messages=messages,
        )
        messages.append({"role": "assistant", "content": resp.content})

        if resp.stop_reason != "tool_use":
            text = "".join(b.text for b in resp.content if b.type == "text")
            _log_interaction(request_id, req.messages[-1], trace, text)
            return {"reply": text, "layers": layers, "request_id": request_id}

        tool_results = []
        for block in resp.content:
            if block.type != "tool_use":
                continue
            t0 = time.time()
            result, geojson = run_tool(block.name, block.input)
            trace.append({
                "tool": block.name, "input": block.input,
                "ok": "error" not in result, "ms": int((time.time() - t0) * 1000),
            })
            if geojson:
                layers.append({"tool": block.name, "geojson": geojson})
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": block.id,
                "content": json.dumps(result, ensure_ascii=False),
                "is_error": "error" in result,
            })
        messages.append({"role": "user", "content": tool_results})

    return {"reply": "This request needed too many steps. Please split it into smaller questions.",
            "layers": layers, "request_id": request_id}


@app.post("/feedback")
def feedback(body: dict):
    # {request_id, rating: "up"|"down", comment}. Feeds your evaluation dataset.
    log.info("FEEDBACK %s", json.dumps(body, ensure_ascii=False))
    return {"ok": True}


def _log_interaction(request_id, user_msg, trace, reply):
    # Replace with your database. These logs become your test set and show
    # which questions users ask that your tools cannot answer yet.
    log.info("INTERACTION %s", json.dumps(
        {"id": request_id, "user": user_msg, "tools": trace, "reply": reply}, ensure_ascii=False))
