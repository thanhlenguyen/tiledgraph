/*
 * map_chat.js — add an agent chat panel to your existing MapLibre map.
 * Usage:  initMapChat(map, { apiUrl: "https://your-backend/chat" })
 * (If your map uses Leaflet, replace drawLayers() with L.geoJSON(layer.geojson).addTo(map).)
 */
function initMapChat(map, { apiUrl }) {
  const history = [];
  let layerIds = [];

  const panel = document.createElement("div");
  panel.innerHTML = `
    <div id="mc-log" style="height:260px;overflow-y:auto;font:14px sans-serif;padding:8px"></div>
    <div style="display:flex;gap:6px;padding:8px">
      <input id="mc-input" style="flex:1;padding:8px" placeholder="Ask about the map... / اسأل عن الخريطة">
      <button id="mc-send">Send</button>
    </div>`;
  Object.assign(panel.style, {
    position: "absolute", right: "12px", bottom: "12px", width: "360px",
    background: "white", borderRadius: "8px", boxShadow: "0 2px 12px rgba(0,0,0,.2)", zIndex: 10,
  });
  map.getContainer().appendChild(panel);

  const logEl = panel.querySelector("#mc-log");
  const input = panel.querySelector("#mc-input");

  function addMsg(who, text) {
    const p = document.createElement("p");
    p.dir = "auto"; // handles Arabic right-to-left automatically
    p.innerHTML = `<b>${who}:</b> `;
    p.appendChild(document.createTextNode(text));
    logEl.appendChild(p);
    logEl.scrollTop = logEl.scrollHeight;
  }

  function drawLayers(layers) {
    layerIds.forEach((id) => { if (map.getLayer(id)) map.removeLayer(id); if (map.getSource(id)) map.removeSource(id); });
    layerIds = [];
    const bounds = new maplibregl.LngLatBounds();
    layers.forEach((layer, i) => {
      const id = `agent-${i}`;
      map.addSource(id, { type: "geojson", data: layer.geojson });
      const geomType = layer.geojson.features?.[0]?.geometry?.type || "";
      if (geomType.includes("Polygon")) {
        map.addLayer({ id, type: "fill", source: id, paint: { "fill-color": "#1f78b4", "fill-opacity": 0.25 } });
      } else if (geomType.includes("Line")) {
        map.addLayer({ id, type: "line", source: id, paint: { "line-color": "#e31a1c", "line-width": 4 } });
      } else {
        map.addLayer({ id, type: "circle", source: id, paint: { "circle-radius": 6, "circle-color": "#33a02c" } });
      }
      layerIds.push(id);
      (layer.geojson.features || []).forEach((f) => extend(bounds, f.geometry.coordinates));
    });
    if (!bounds.isEmpty()) map.fitBounds(bounds, { padding: 60, maxZoom: 15 });
  }

  function extend(bounds, c) {
    if (typeof c[0] === "number") bounds.extend(c); else c.forEach((x) => extend(bounds, x));
  }

  async function send() {
    const text = input.value.trim();
    if (!text) return;
    input.value = "";
    addMsg("You", text);
    history.push({ role: "user", content: text });
    const b = map.getBounds();
    try {
      const res = await fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: history,
          map_view: { center: map.getCenter(), zoom: map.getZoom(),
                      bbox: [b.getWest(), b.getSouth(), b.getEast(), b.getNorth()] },
        }),
      });
      const data = await res.json();
      history.push({ role: "assistant", content: data.reply });
      addMsg("Agent", data.reply);
      if (data.layers?.length) drawLayers(data.layers);
    } catch (e) {
      addMsg("Agent", "Connection error. Please try again.");
    }
  }

  panel.querySelector("#mc-send").onclick = send;
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") send(); });
}
