"""
gis_tools.py
Wraps your existing GIS services (geocoding, nearest facility, isochrone, TSP, VRP)
as tools an LLM agent can call.

ONLY edit the ENDPOINTS and the small adapter functions to match your real APIs.
The tool schemas (names, descriptions, parameters) are what the model sees,
so keep descriptions precise: they decide when and how the agent uses each tool.
"""
import os
import httpx

GIS_BASE_URL = os.getenv("GIS_BASE_URL", "http://localhost:8080")
GIS_API_KEY = os.getenv("GIS_API_KEY", "")

# Map each tool to your real endpoint paths
ENDPOINTS = {
    "geocode_address": "/api/geocode",
    "reverse_geocode": "/api/reverse-geocode",
    "find_nearest_facility": "/api/nearest-facility",
    "compute_isochrone": "/api/isochrone",
    "solve_tsp": "/api/tsp",
    "optimize_vehicle_routes": "/api/vrp",
}

LATLON = {
    "type": "object",
    "properties": {"lat": {"type": "number"}, "lon": {"type": "number"}},
    "required": ["lat", "lon"],
}

# ---------------------------------------------------------------------------
# Tool schemas shown to the model
# ---------------------------------------------------------------------------
TOOLS = [
    {
        "name": "geocode_address",
        "description": (
            "Convert a Saudi address, place name, district, or National Address short code "
            "(e.g. 'RRRD2929') into coordinates. Accepts Arabic or English. "
            "ALWAYS call this first when the user mentions a place by name instead of coordinates. "
            "Returns up to 5 candidates with a confidence score; if the top confidence is below 0.7, "
            "ask the user which candidate they mean."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Address text or short code"},
                "city": {"type": "string", "description": "Optional city to narrow results, e.g. 'Riyadh'"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "reverse_geocode",
        "description": "Get the National Address, district, and city for a coordinate.",
        "input_schema": LATLON,
    },
    {
        "name": "find_nearest_facility",
        "description": (
            "Find the nearest facilities of a given type to a location, ranked by ROAD travel time "
            "(not straight-line distance). Use for questions like 'closest branch/hospital/locker to X'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "origin": LATLON,
                "facility_type": {
                    "type": "string",
                    "description": "e.g. 'post_office', 'hospital', 'pharmacy', 'warehouse', 'locker'",
                },
                "limit": {"type": "integer", "default": 3, "maximum": 20},
            },
            "required": ["origin", "facility_type"],
        },
    },
    {
        "name": "compute_isochrone",
        "description": (
            "Compute the area reachable from a point within given travel times. "
            "Use for coverage, catchment, and accessibility questions."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "origin": LATLON,
                "minutes": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "One or more time bands, e.g. [10, 20, 30]",
                },
                "mode": {"type": "string", "enum": ["driving", "walking"], "default": "driving"},
            },
            "required": ["origin", "minutes"],
        },
    },
    {
        "name": "solve_tsp",
        "description": "Find the best visiting order for ONE vehicle visiting a set of stops.",
        "input_schema": {
            "type": "object",
            "properties": {
                "start": LATLON,
                "stops": {"type": "array", "items": LATLON},
                "return_to_start": {"type": "boolean", "default": True},
            },
            "required": ["start", "stops"],
        },
    },
    {
        "name": "optimize_vehicle_routes",
        "description": (
            "Plan routes for MULTIPLE vehicles (VRP) with capacities and time windows. "
            "This only CREATES a draft plan; it never dispatches drivers. "
            "Use when the user asks to plan, re-plan, or balance a fleet."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "depot": LATLON,
                "vehicles": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "capacity": {"type": "integer"},
                            "shift_start": {"type": "string", "description": "HH:MM"},
                            "shift_end": {"type": "string", "description": "HH:MM"},
                        },
                        "required": ["id"],
                    },
                },
                "jobs": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "location": LATLON,
                            "demand": {"type": "integer", "default": 1},
                            "time_window": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "[start HH:MM, end HH:MM]",
                            },
                        },
                        "required": ["id", "location"],
                    },
                },
            },
            "required": ["depot", "vehicles", "jobs"],
        },
    },
]


# ---------------------------------------------------------------------------
# Execution
# ---------------------------------------------------------------------------
def _call(tool_name: str, payload: dict) -> dict:
    url = GIS_BASE_URL + ENDPOINTS[tool_name]
    headers = {"Authorization": f"Bearer {GIS_API_KEY}"} if GIS_API_KEY else {}
    with httpx.Client(timeout=60) as client:
        r = client.post(url, json=payload, headers=headers)
        r.raise_for_status()
        return r.json()


def run_tool(name: str, args: dict) -> tuple[dict, dict | None]:
    """
    Execute a tool. Returns (result_for_model, geojson_layer_for_map).

    Keep result_for_model SMALL (summaries, ids, numbers). Large geometries waste
    tokens and the model does not need them; send them to the map instead.
    """
    if name not in ENDPOINTS:
        return {"error": f"Unknown tool {name}"}, None
    try:
        raw = _call(name, args)
    except httpx.HTTPError as e:
        return {"error": f"GIS service failed: {e}"}, None

    # Adapter: split raw response into a compact summary + a map layer.
    # Adjust the keys below to your real response format.
    geojson = raw.pop("geojson", None)
    summary = raw
    if name == "compute_isochrone" and geojson:
        summary = {"bands_minutes": args["minutes"], "area_km2": raw.get("area_km2")}
    return summary, geojson
