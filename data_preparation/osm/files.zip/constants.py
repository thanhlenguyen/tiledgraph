"""
constants.py — shared constants for the OSM topology builder.
"""

# Maps input numeric columns to OSM highway tag values.
# FOW (Form Of Way): 3/4 = ramp/link.  Subtype: 1=trunk, 2=primary, 3=secondary.
HIGHWAY_SQL = """
CASE
    WHEN FOW IN (3,4) AND Subtype = 1 THEN 'trunk_link'
    WHEN FOW IN (3,4) AND Subtype = 2 THEN 'primary_link'
    WHEN FOW IN (3,4) AND Subtype = 3 THEN 'secondary_link'
    WHEN FOW IN (3,4)                  THEN 'tertiary_link'
    WHEN Subtype = 1                   THEN 'trunk'
    WHEN Subtype = 2                   THEN 'primary'
    ELSE                                    'road'
END
"""

# Print tile progress every N tiles processed
TILE_LOG_EVERY = 500
