// =============================================================================
// RouteOps — scripts.js
// Wired to the full redesigned UI: vehicles table, depots table, jobs table,
// results panel, CSV import, profile selector, sidebar toggles.
// =============================================================================

// ---------------------------------------------------------------------------
// Map style definitions
// ---------------------------------------------------------------------------
const STYLES = [
    { id: 'basic-style', name: 'Default',   url: '/styles/style.json',      pitch: 0,  zoom: 13, bearing: 0   },
    { id: 'sat-style',   name: 'Satellite', url: '/styles/style_sat.json',  pitch: 0,  zoom: 13, bearing: 0   },
    { id: '3d-style',    name: '3D',        url: '/styles/style_3d.json',   pitch: 45, zoom: 14, bearing: 0   },
    { id: 'bdf-style',   name: 'BDF',       url: '/styles/style_bdf.json',  pitch: 60, zoom: 17, bearing: -20 }
];

// ---------------------------------------------------------------------------
// Backend
// ---------------------------------------------------------------------------
const BACKEND_URL   = '/api';
const API_ENDPOINTS = {
    route:          `${BACKEND_URL}/route`,
    matrix:         `${BACKEND_URL}/matrix`,
    isochrone:      `${BACKEND_URL}/isochrone`,
    optimize:       `${BACKEND_URL}/optimize`,
    optimize_route: `${BACKEND_URL}/optimize_route`,
    health:         `${BACKEND_URL}/health`,
};
const REQUEST_TIMEOUT = 120_000;

// ---------------------------------------------------------------------------
// Route colors (one per vehicle)
// ---------------------------------------------------------------------------
const ROUTE_COLORS = [
    '#00d4ff','#ff6b6b','#51cf66','#ffd43b',
    '#cc5de8','#ff922b','#74c0fc','#a9e34b'
];

// ---------------------------------------------------------------------------
// Click modes
// ---------------------------------------------------------------------------
const MODE = { NONE: 'none', DEPOT: 'depot', JOB: 'job', ISOCHRONE: 'isochrone' };
let clickMode = MODE.NONE;

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
let map;
let currentStyleId = STYLES[0].id;
let currentCenter  = [106.6297, 10.8231];
let currentZoom    = 13;
let currentPitch   = 0;
let currentBearing = 0;

let globalProfile  = 'auto'; // from navbar profile selector

// Depots: [{ id, name, lngLat, marker }]
let depots  = [];
// Jobs:   [{ id, location:[lng,lat], service, marker }]
let jobs    = [];
// Vehicles: [{ id, profile, capacity, twStart, twEnd }]
let vehicles = [];

// Layer IDs
const ISO_SOURCE       = 'isochrone-source';
const ISO_LAYER_FILL   = 'isochrone-fill';
const ISO_LAYER_BORDER = 'isochrone-border';

// =============================================================================
// INIT
// =============================================================================
function initMap() {
    map = new maplibregl.Map({
        container: 'map',
        style:     STYLES[0].url,
        center:    currentCenter,
        zoom:      currentZoom,
        pitch:     currentPitch,
        bearing:   currentBearing,
        maxPitch:  85
    });

    map.on('moveend', () => {
        currentCenter  = map.getCenter().toArray();
        currentZoom    = map.getZoom();
        currentPitch   = map.getPitch();
        currentBearing = map.getBearing();
    });

    map.addControl(new maplibregl.NavigationControl(), 'top-right');
    map.addControl(new maplibregl.ScaleControl(),      'bottom-left');
    map.addControl(new maplibregl.FullscreenControl(), 'top-right');
    map.addControl(new LayerSwitcherControl(),         'bottom-right');

    map.on('load', () => console.log('Map loaded'));

    map.on('click', (e) => {
        const lngLat = [e.lngLat.lng, e.lngLat.lat];
        if      (clickMode === MODE.DEPOT)     _placeDepot(lngLat);
        else if (clickMode === MODE.JOB)       _addJob(lngLat);
        else if (clickMode === MODE.ISOCHRONE) _runIsochrone(lngLat);
    });

    map.on('error', (e) => console.error('Map error:', e));
}

// =============================================================================
// MODE
// =============================================================================
function setMode(mode) {
    if (mode === clickMode) mode = MODE.NONE; // toggle off
    clickMode = mode;

    map.getCanvas().style.cursor = (mode === MODE.NONE) ? '' : 'crosshair';

    // Update [data-mode] buttons everywhere
    document.querySelectorAll('[data-mode]').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.mode === mode);
    });

    // Mode indicator pill
    const indicator = document.getElementById('mode-indicator');
    const modeText  = document.getElementById('modeText');
    if (mode === MODE.NONE) {
        indicator.classList.add('hidden');
    } else {
        const labels = {
            [MODE.DEPOT]:     '📍 Click map to place depot',
            [MODE.JOB]:       '📌 Click map to add jobs — click button again to stop',
            [MODE.ISOCHRONE]: '🕐 Click a location for isochrone'
        };
        modeText.textContent = labels[mode] || '';
        indicator.classList.remove('hidden');
    }
}
window.setMode = setMode;

// =============================================================================
// PROFILE SELECTOR
// =============================================================================
document.querySelectorAll('.profile-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.profile-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        globalProfile = btn.dataset.profile;
        setStatus(`Profile set to "${globalProfile}"`, 'info');
    });
});

// =============================================================================
// DEPOTS
// =============================================================================
function _placeDepot(lngLat) {
    const id   = depots.length + 1;
    const name = `Depot ${id}`;

    const el = document.createElement('div');
    el.className = 'marker-depot';
    el.innerHTML = '<div class="marker-depot-inner"></div>';
    el.title     = name;

    const marker = new maplibregl.Marker({ element: el })
        .setLngLat(lngLat)
        .setPopup(new maplibregl.Popup({ offset: 20 }).setHTML(
            `<b>${name}</b><br><span style="font-family:var(--font-mono);font-size:11px;color:var(--text-muted)">${lngLat[1].toFixed(5)}, ${lngLat[0].toFixed(5)}</span>`
        ))
        .addTo(map);

    depots.push({ id, name, lngLat, marker });
    _renderDepotTable();
    _updateJobsStats();

    setStatus(`${name} placed`, 'success');
    setMode(MODE.NONE);
}

function _renderDepotTable() {
    const tbody = document.getElementById('depotTableBody');
    if (depots.length === 0) {
        tbody.innerHTML = '<tr class="empty-row"><td colspan="5">No depots yet.<br>Click "Place Depot" then click the map.</td></tr>';
        return;
    }
    tbody.innerHTML = depots.map(d => `
        <tr onclick="_flyTo(${d.lngLat[0]},${d.lngLat[1]})">
            <td>${d.id}</td>
            <td>${d.name}</td>
            <td>${d.lngLat[1].toFixed(4)}</td>
            <td>${d.lngLat[0].toFixed(4)}</td>
            <td><button class="row-action" onclick="event.stopPropagation();_removeDepot(${d.id})" title="Remove">✕</button></td>
        </tr>
    `).join('');
}

window._removeDepot = function(id) {
    const idx = depots.findIndex(d => d.id === id);
    if (idx === -1) return;
    depots[idx].marker.remove();
    depots.splice(idx, 1);
    _renderDepotTable();
    _updateJobsStats();
};

// =============================================================================
// JOBS
// =============================================================================
function _addJob(lngLat) {
    const id = jobs.length + 1;

    const el = document.createElement('div');
    el.className   = 'marker-job';
    el.textContent = id;

    const marker = new maplibregl.Marker({ element: el })
        .setLngLat(lngLat)
        .setPopup(new maplibregl.Popup({ offset: 20 }).setHTML(
            `<b>Job ${id}</b><br>
             <span style="font-family:var(--font-mono);font-size:11px;color:var(--text-muted)">${lngLat[1].toFixed(5)}, ${lngLat[0].toFixed(5)}</span><br>
             <span style="font-size:11px;color:var(--text-secondary)">Service: 60 s</span>`
        ))
        .addTo(map);

    jobs.push({ id, location: lngLat, service: 60, marker });
    _renderJobTable();
    _updateJobsStats();
}

function _renderJobTable() {
    const tbody = document.getElementById('jobTableBody');
    if (jobs.length === 0) {
        tbody.innerHTML = '<tr class="empty-row"><td colspan="5">No jobs yet.<br>Click "Add Jobs" then click the map.</td></tr>';
        return;
    }
    tbody.innerHTML = jobs.map(j => `
        <tr onclick="_flyTo(${j.location[0]},${j.location[1]})">
            <td>${j.id}</td>
            <td>${j.location[1].toFixed(4)}</td>
            <td>${j.location[0].toFixed(4)}</td>
            <td>${j.service}s</td>
            <td><button class="row-action" onclick="event.stopPropagation();_removeJob(${j.id})" title="Remove">✕</button></td>
        </tr>
    `).join('');
}

window._removeJob = function(id) {
    const idx = jobs.findIndex(j => j.id === id);
    if (idx === -1) return;
    jobs[idx].marker.remove();
    jobs.splice(idx, 1);
    // Renumber remaining
    jobs.forEach((j, i) => { j.id = i + 1; j.marker.getElement().textContent = j.id; });
    _renderJobTable();
    _updateJobsStats();
};

window.clearJobs = function() {
    jobs.forEach(j => j.marker.remove());
    jobs = [];
    _removeAllRouteLayers();
    _renderJobTable();
    _updateJobsStats();
    setMode(MODE.NONE);
    setStatus('Jobs cleared', 'info');
};

function _updateJobsStats() {
    document.getElementById('jobCount').textContent   = `${jobs.length} job${jobs.length !== 1 ? 's' : ''}`;
    document.getElementById('depotCount').textContent = `${depots.length} depot${depots.length !== 1 ? 's' : ''}`;
}

window.clearAll = function() {
    window.clearJobs();
    depots.forEach(d => d.marker.remove());
    depots = [];
    _renderDepotTable();
    _updateJobsStats();
    _removeIsochroneLayer();
    setMode(MODE.NONE);
    setStatus('Map cleared', 'info');
};

// =============================================================================
// VEHICLES
// =============================================================================
let _editingVehicle = null;

window.addVehicle = function() {
    document.getElementById('vId').value       = `V-0${vehicles.length + 1}`;
    document.getElementById('vProfile').value  = '';
    document.getElementById('vCapacity').value = '';
    document.getElementById('vTwStart').value  = '08:00';
    document.getElementById('vTwEnd').value    = '18:00';
    openModal('vehicleModal');
};

window.saveVehicle = function() {
    const id       = document.getElementById('vId').value.trim() || `V-0${vehicles.length + 1}`;
    const profile  = document.getElementById('vProfile').value   || '';
    const capacity = parseInt(document.getElementById('vCapacity').value) || 0;
    const twStart  = document.getElementById('vTwStart').value;
    const twEnd    = document.getElementById('vTwEnd').value;

    vehicles.push({ id, profile, capacity, twStart, twEnd });
    _renderVehicleTable();
    closeModal('vehicleModal');
    setStatus(`Vehicle ${id} added`, 'success');
};

function _renderVehicleTable() {
    const tbody = document.getElementById('vehicleTableBody');
    if (vehicles.length === 0) {
        tbody.innerHTML = '<tr class="empty-row"><td colspan="5">No vehicles yet.</td></tr>';
        return;
    }
    tbody.innerHTML = vehicles.map((v, i) => `
        <tr>
            <td><span style="color:${ROUTE_COLORS[i % ROUTE_COLORS.length]};font-weight:600">${v.id}</span></td>
            <td>${v.profile || globalProfile}</td>
            <td>${v.capacity || '—'}</td>
            <td style="font-size:10px">${v.twStart}–${v.twEnd}</td>
            <td><button class="row-action" onclick="_removeVehicle(${i})" title="Remove">✕</button></td>
        </tr>
    `).join('');
}

window._removeVehicle = function(idx) {
    vehicles.splice(idx, 1);
    _renderVehicleTable();
};

// =============================================================================
// OPTIMISE (VROOM)
// =============================================================================
window.optimizeRoute = async function() {
    if (depots.length === 0) {
        setStatus('Place at least one depot first', 'warn'); return;
    }
    if (jobs.length === 0) {
        setStatus('Add at least one job first', 'warn'); return;
    }

    setMode(MODE.NONE);
    const btn = document.getElementById('btnOptimize');
    btn.classList.add('loading');
    setStatus('Optimising…', 'loading');

    // Build vehicles — fall back to one default vehicle per depot if none defined
    let vroomVehicles;
    if (vehicles.length > 0) {
        vroomVehicles = vehicles.map((v, i) => ({
            id:      i + 1,
            start:   depots[0].lngLat,
            end:     depots[0].lngLat,
            profile: v.profile || globalProfile,
            ...(v.capacity > 0 ? { capacity: [v.capacity] } : {})
        }));
    } else {
        // Auto-create one vehicle per depot
        vroomVehicles = depots.map((d, i) => ({
            id:      i + 1,
            start:   d.lngLat,
            end:     d.lngLat,
            profile: globalProfile
        }));
    }

    const payload = {
        vehicles: vroomVehicles,
        jobs: jobs.map(j => ({
            id:       j.id,
            location: j.location,
            service:  j.service
        }))
    };

    try {
        const result = await fetchWithTimeout(API_ENDPOINTS.optimize_route, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify(payload)
        });

        console.log('VROOM result:', result);
        _removeAllRouteLayers();
        _renderResults(result);

        const totalKm   = (result.vroom.summary.distance / 1000).toFixed(1);
        const totalMins = Math.round(result.vroom.summary.duration / 60);
        setStatus(`✅ Optimised — ${totalKm} km · ${totalMins} min`, 'success');

        // Open right panel
        const rp = document.getElementById('right-panel');
        rp.classList.remove('collapsed');

    } catch (err) {
        console.error(err);
        setStatus(`Error: ${err.message}`, 'error');
    } finally {
        btn.classList.remove('loading');
    }
};

// =============================================================================
// RENDER RESULTS
// =============================================================================
function _renderResults(result) {
    const vroom = result.vroom;
    const geo   = result.geojson;

    // Summary
    document.getElementById('sumDistance').textContent = (vroom.summary.distance / 1000).toFixed(1);
    document.getElementById('sumDuration').textContent = Math.round(vroom.summary.duration / 60);
    document.getElementById('sumVehicles').textContent = vroom.routes.length;
    const unserved = vroom.unassigned ? vroom.unassigned.length : 0;
    document.getElementById('sumUnserved').textContent = unserved;
    document.getElementById('resultBadge').textContent = `${vroom.routes.length} route${vroom.routes.length !== 1 ? 's' : ''}`;

    // Draw each route
    geo.features.forEach((feature, i) => {
        const color    = ROUTE_COLORS[i % ROUTE_COLORS.length];
        const sourceId = `route-source-${i}`;
        const layerId  = `route-layer-${i}`;

        map.addSource(sourceId, { type: 'geojson', data: feature });

        // Casing (outline)
        map.addLayer({
            id: `${layerId}-case`, type: 'line', source: sourceId,
            layout: { 'line-join': 'round', 'line-cap': 'round' },
            paint:  { 'line-color': '#000', 'line-width': 8, 'line-opacity': 0.3 }
        });
        // Main line
        map.addLayer({
            id: layerId, type: 'line', source: sourceId,
            layout: { 'line-join': 'round', 'line-cap': 'round' },
            paint:  { 'line-color': color, 'line-width': 5, 'line-opacity': 0.95 }
        });

        // Color assigned job markers
        const steps = feature.properties.steps || [];
        steps.filter(s => s.type === 'job').forEach(s => {
            const job = jobs.find(j => j.id === s.id);
            if (job) {
                const el = job.marker.getElement();
                el.style.setProperty('--job-color', color);
                el.classList.add('assigned');
                el.style.borderColor = color;
                el.style.color       = color;
            }
        });
    });

    // Per-vehicle accordion
    const accordion = document.getElementById('routesAccordion');
    accordion.innerHTML = vroom.routes.map((route, i) => {
        const color = ROUTE_COLORS[i % ROUTE_COLORS.length];
        const km    = (route.distance / 1000).toFixed(1);
        const mins  = Math.round(route.duration / 60);
        const stops = route.steps.filter(s => s.type === 'job').length;

        const stepsHtml = route.steps.map((step, si) => {
            const typeLabel = { start: '🏠 Start', job: '📌 Stop', end: '🏠 End', break: '☕ Break' }[step.type] || step.type;
            const loc = step.location ? `${step.location[1].toFixed(4)}, ${step.location[0].toFixed(4)}` : '';
            return `
                <div class="route-step" onclick="_flyTo(${step.location ? step.location[0] : 0},${step.location ? step.location[1] : 0})">
                    <div class="step-num">${si + 1}</div>
                    <div class="step-body">
                        <div class="step-type">${typeLabel}${step.id ? ` #${step.id}` : ''}</div>
                        ${loc ? `<div class="step-coords">${loc}</div>` : ''}
                    </div>
                </div>`;
        }).join('');

        return `
            <div class="route-card" id="routeCard${i}">
                <div class="route-card-header" onclick="_toggleRouteCard(${i})">
                    <div class="route-swatch" style="background:${color}"></div>
                    <div class="route-card-title">${vehicles[i] ? vehicles[i].id : `Vehicle ${i + 1}`}</div>
                    <div class="route-card-stats">${km} km<br>${mins} min · ${stops} stops</div>
                    <div class="route-chevron">▶</div>
                </div>
                <div class="route-steps">${stepsHtml}</div>
            </div>`;
    }).join('');
}

window._toggleRouteCard = function(i) {
    document.getElementById(`routeCard${i}`)?.classList.toggle('open');
};

function _removeAllRouteLayers() {
    if (!map.isStyleLoaded()) return;
    // Remove any previously added route layers/sources
    const style  = map.getStyle();
    const layers = style.layers.filter(l => l.id.startsWith('route-layer-') || l.id.startsWith('route-layer-') );
    layers.forEach(l => { try { map.removeLayer(l.id); } catch {} });
    // Remove sources
    const sources = Object.keys(style.sources).filter(s => s.startsWith('route-source-'));
    sources.forEach(s => { try { map.removeSource(s); } catch {} });

    // Reset job marker colors
    jobs.forEach(j => {
        const el = j.marker.getElement();
        el.classList.remove('assigned');
        el.style.borderColor = '';
        el.style.color       = '';
    });

    // Clear results panel
    document.getElementById('routesAccordion').innerHTML = '';
    document.getElementById('sumDistance').textContent = '—';
    document.getElementById('sumDuration').textContent = '—';
    document.getElementById('sumVehicles').textContent = '—';
    document.getElementById('sumUnserved').textContent = '—';
    document.getElementById('resultBadge').textContent = '';
}

// =============================================================================
// ISOCHRONE
// =============================================================================
async function _runIsochrone(lngLat) {
    setMode(MODE.NONE);
    setStatus('Calculating isochrone…', 'loading');

    const payload = {
        locations: [{ lon: lngLat[0], lat: lngLat[1] }],
        costing:   globalProfile,
        contours:  [
            { time: 5,  color: 'ff4444' },
            { time: 10, color: 'ffaa00' },
            { time: 15, color: '22cc66' }
        ],
        polygons: true
    };

    try {
        const geojson = await fetchWithTimeout(API_ENDPOINTS.isochrone, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        _drawIsochrone(geojson);
        setStatus('✅ Isochrone: red=5 min · amber=10 min · green=15 min', 'success');
    } catch (err) {
        console.error(err);
        setStatus(`Error: ${err.message}`, 'error');
    }
}

function _drawIsochrone(geojson) {
    _removeIsochroneLayer();
    map.addSource(ISO_SOURCE, { type: 'geojson', data: geojson });
    map.addLayer({ id: ISO_LAYER_FILL,   type: 'fill', source: ISO_SOURCE, paint: { 'fill-color': ['get', 'color'], 'fill-opacity': 0.12 } });
    map.addLayer({ id: ISO_LAYER_BORDER, type: 'line', source: ISO_SOURCE, paint: { 'line-color': ['get', 'color'], 'line-width': 2 } });
}

function _removeIsochroneLayer() {
    if (map.getLayer(ISO_LAYER_BORDER)) map.removeLayer(ISO_LAYER_BORDER);
    if (map.getLayer(ISO_LAYER_FILL))   map.removeLayer(ISO_LAYER_FILL);
    if (map.getSource(ISO_SOURCE))       map.removeSource(ISO_SOURCE);
}

window.clearIsochrone = function() {
    _removeIsochroneLayer();
    setStatus('Isochrone removed', 'info');
};

// =============================================================================
// CSV IMPORT
// =============================================================================
window.handleImport = function() { openModal('importModal'); };

window.importCSV = function() {
    const raw = document.getElementById('csvInput').value.trim();
    if (!raw) return;

    const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);
    // Skip header if present
    const start = isNaN(parseFloat(lines[0].split(',')[0])) ? 1 : 0;
    let added = 0;

    lines.slice(start).forEach(line => {
        const [latStr, lonStr, svcStr] = line.split(',');
        const lat = parseFloat(latStr);
        const lon = parseFloat(lonStr);
        const svc = parseInt(svcStr) || 60;
        if (isNaN(lat) || isNaN(lon)) return;
        _addJob([lon, lat]);
        // Update service time for last added job
        jobs[jobs.length - 1].service = svc;
        added++;
    });

    closeModal('importModal');
    document.getElementById('csvInput').value = '';
    setStatus(`Imported ${added} jobs from CSV`, 'success');
    _renderJobTable();
};

// =============================================================================
// EXPORT
// =============================================================================
window.handleExport = function() {
    if (jobs.length === 0) { setStatus('No jobs to export', 'warn'); return; }
    const header = 'id,lat,lon,service';
    const rows   = jobs.map(j => `${j.id},${j.location[1]},${j.location[0]},${j.service}`);
    const csv    = [header, ...rows].join('\n');
    const blob   = new Blob([csv], { type: 'text/csv' });
    const a      = Object.assign(document.createElement('a'), {
        href: URL.createObjectURL(blob), download: 'jobs-export.csv'
    });
    a.click();
    setStatus(`Exported ${jobs.length} jobs`, 'success');
};

// =============================================================================
// SIDEBAR TOGGLES
// =============================================================================
window.toggleSidebar = function(side) {
    const el = document.getElementById(side === 'left' ? 'left-sidebar' : 'right-panel');
    el.classList.toggle('collapsed');
};

// =============================================================================
// TABS
// =============================================================================
window.switchTab = function(name) {
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.id === `tab-${name}`));
};

// =============================================================================
// MODAL HELPERS
// =============================================================================
window.openModal  = function(id) { document.getElementById(id).classList.remove('hidden'); };
window.closeModal = function(id) { document.getElementById(id).classList.add('hidden'); };
// Click backdrop to close
document.querySelectorAll('.modal-backdrop').forEach(el => {
    el.addEventListener('click', e => { if (e.target === el) el.classList.add('hidden'); });
});

// =============================================================================
// POLYLINE DECODER  (precision 6 — Valhalla / VROOM)
// =============================================================================
function decodePolyline6(encoded) {
    const coords = [];
    let index = 0, lat = 0, lng = 0;
    const len = encoded.length;
    while (index < len) {
        let b, shift = 0, result = 0;
        do { b = encoded.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
        lat += (result & 1) ? ~(result >> 1) : (result >> 1);
        shift = 0; result = 0;
        do { b = encoded.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
        lng += (result & 1) ? ~(result >> 1) : (result >> 1);
        coords.push([lng / 1e6, lat / 1e6]);
    }
    return coords;
}

// =============================================================================
// STYLE SWITCHER
// =============================================================================
class LayerSwitcherControl {
    onAdd(map) {
        this._map = map;
        this._container = document.createElement('div');
        this._container.className = 'maplibregl-ctrl maplibregl-ctrl-group layer-switcher';
        STYLES.forEach((s, idx) => {
            const btn = document.createElement('button');
            btn.type = 'button'; btn.title = s.name; btn.textContent = s.name;
            if (idx === 0) btn.classList.add('active');
            btn.addEventListener('click', () => {
                this._container.querySelectorAll('button').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                currentStyleId = s.id;
                map.setStyle(s.url);
                map.once('styledata', () => {
                    _removeAllRouteLayers();   // layers are lost on style swap
                    applyViewForStyle(s);
                });
            });
            this._container.appendChild(btn);
        });
        return this._container;
    }
    onRemove() { this._container.parentNode?.removeChild(this._container); }
}

function applyViewForStyle(s) {
    map.easeTo({
        center: currentCenter, zoom: s.zoom ?? currentZoom,
        pitch: s.pitch ?? currentPitch, bearing: s.bearing ?? currentBearing,
        duration: 1000
    });
}

// =============================================================================
// STATUS TOAST
// =============================================================================
let _statusTimer = null;
function setStatus(msg, type = 'info') {
    const el = document.getElementById('status-toast');
    if (!el) return;
    el.textContent = msg;
    el.className   = `status-toast status-${type}`;
    clearTimeout(_statusTimer);
    if (type === 'success' || type === 'info') {
        _statusTimer = setTimeout(() => { el.textContent = ''; el.className = 'status-toast'; }, 6000);
    }
}
window.setStatus = setStatus;

// =============================================================================
// FLY TO
// =============================================================================
window._flyTo = function(lng, lat) {
    if (!lng || !lat) return;
    map.flyTo({ center: [lng, lat], zoom: Math.max(map.getZoom(), 15), speed: 1.5 });
};

// =============================================================================
// FETCH WITH TIMEOUT
// =============================================================================
async function fetchWithTimeout(url, options = {}) {
    const controller = new AbortController();
    const tid = setTimeout(() => controller.abort(), REQUEST_TIMEOUT);
    try {
        const response = await fetch(url, { ...options, signal: controller.signal });
        clearTimeout(tid);
        if (!response.ok) {
            let detail = `${response.status} ${response.statusText}`;
            try { const b = await response.json(); if (b.detail) detail = JSON.stringify(b.detail); } catch {}
            throw new Error(detail);
        }
        return response.json();
    } catch (err) {
        clearTimeout(tid);
        if (err.name === 'AbortError') throw new Error('Request timed out — try again');
        throw err;
    }
}

// =============================================================================
// BOOT
// =============================================================================
window.addEventListener('load', initMap);
